package com.tias.back.entity;

public enum MedicationStatus {
    CRITICO,
    BAIXO,
    OK;
}