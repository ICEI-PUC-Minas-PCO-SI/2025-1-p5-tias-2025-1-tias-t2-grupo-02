package com.tias.back.controller;

public class PatientController {
    
}
