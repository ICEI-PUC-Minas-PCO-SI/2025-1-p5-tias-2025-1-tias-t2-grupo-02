package com.tias.back.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter @Setter
@NoArgsConstructor @AllArgsConstructor @Builder
public class MedicationRequestDTO {
    @NotNull(message = "PatientId é obrigatório")
    private java.util.UUID patientId;

    @NotBlank(message = "Description é obrigatório")
    private String description;

    @NotBlank(message = "Dosage é obrigatório")
    private String dosage;

    @NotBlank(message = "addedAt é obrigatório")
    @Pattern(
      regexp = "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:Z|[+-]\\d{2}:\\d{2})$",
      message = "addedAt deve usar formato ISO date-time, ex: 2025-06-18T10:00:00Z"
    )
    private String addedAt;
}
