package com.tias.back.dto;

import lombok.*;
import java.util.UUID;

@Getter @Setter
@NoArgsConstructor @AllArgsConstructor @Builder
public class PatientResponseDTO {
    private UUID patientId;
    private String name;
    private String cpf;
    private String birthdate;
    private String address;
    private String condition;
    private boolean isActive;
}
