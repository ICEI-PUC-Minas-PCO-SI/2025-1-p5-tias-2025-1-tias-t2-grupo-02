package com.tias.back.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter @Setter
@NoArgsConstructor @AllArgsConstructor @Builder
public class DocumentationRequestDTO {
    @NotNull(message = "PatientId é obrigatório")
    private java.util.UUID patientId;

    @NotBlank(message = "Description é obrigatório")
    private String description;

    @NotBlank(message = "Location é obrigatório")
    private String location;

    @NotBlank(message = "addedAt é obrigatório")
    @Pattern(
      regexp = "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:Z|[+-]\\d{2}:\\d{2})$",
      message = "addedAt deve usar formato ISO date-time, ex: 2025-06-18T10:30:00Z"
    )
    private String addedAt;
}
