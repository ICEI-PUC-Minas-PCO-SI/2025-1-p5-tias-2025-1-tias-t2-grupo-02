package com.tias.back.dto;

import java.util.UUID;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserDTO {
    private UUID userId;
    private String name;
    private Integer cpf;
    private String email;
    private Integer activatedAt;
    private Integer deactivatedAt;
}
