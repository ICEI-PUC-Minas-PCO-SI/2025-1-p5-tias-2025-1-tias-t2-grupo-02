package com.tias.back.service;

import com.tias.back.dto.UserDTO;
import com.tias.back.entity.User;
import com.tias.back.exception.ResourceNotFoundException;
import com.tias.back.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class UserService {

    private final UserRepository repository;

    public UserService(UserRepository repository) {
        this.repository = repository;
    }

    public UserDTO create(UserDTO dto) {
        User entity = toEntity(dto);
        User saved = repository.save(entity);
        return toDto(saved);
    }

    public UserDTO getById(UUID id) {
        User entity = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + id));
        return toDto(entity);
    }

    public List<UserDTO> getAll() {
        return repository.findAll()
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public UserDTO update(UUID id, UserDTO dto) {
        User entity = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + id));
        entity.setUserId(dto.getUserId());
        entity.setName(dto.getName());
        entity.setCpf(dto.getCpf());
        entity.setEmail(dto.getEmail());
        entity.setActivatedAt(dto.getActivatedAt());
        entity.setDeactivatedAt(dto.getDeactivatedAt());
        User updated = repository.save(entity);
        return toDto(updated);
    }

    public void delete(UUID id) {
        repository.deleteById(id);
    }

    private User toEntity(UserDTO dto) {
        User entity = new User();
        entity.setUserId(dto.getUserId());
        entity.setName(dto.getName());
        entity.setCpf(dto.getCpf());
        entity.setEmail(dto.getEmail());
        entity.setActivatedAt(dto.getActivatedAt());
        entity.setDeactivatedAt(dto.getDeactivatedAt());
        return entity;
    }

    private UserDTO toDto(User entity) {
        return UserDTO.builder()
                .userId(entity.getUserId())
                .name(entity.getName())
                .cpf(entity.getCpf())
                .email(entity.getEmail())
                .activatedAt(entity.getActivatedAt())
                .deactivatedAt(entity.getDeactivatedAt())
                .build();
    }
}
